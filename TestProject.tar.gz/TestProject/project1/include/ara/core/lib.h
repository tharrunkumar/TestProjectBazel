#pragma once
#include <iostream>

void demoObj();