#include "ara/core/lib.h"

void demoObj()
{
    std::cout << " :: Invoked the demoObj :: " << std::endl;
}