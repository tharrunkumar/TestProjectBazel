#include "ara/core/lib.h"

int main()
{
    demoObj();
    return 0;
}